package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingMallmgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingMallmgmtApplication.class, args);
	}

}
